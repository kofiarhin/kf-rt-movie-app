const useDiscovered = () => {
  return { data: "get discovered data" };
};

export default useDiscovered;

// import { apiKey} from "../config/lib"
// const year = 2023;
// const pageNumber = 1;

// const discoverUrl = `https://api.themoviedb.org/3/discover/tv?api_key=${apiKey}&language=en-US&sort_by=popularity.desc&first_air_date_year=${year}&page=${pageNumber}`;
