const Footer = () => {
  return (
    <footer>
      <p className="small center">Created by Kofi Arhin</p>
    </footer>
  );
};

export default Footer;
